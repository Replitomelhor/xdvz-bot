const { ApplicationCommandType, EmbedBuilder } = require("discord.js");
const { joinVoiceChannel, getVoiceConnection } = require("@discordjs/voice");
const { owner } = require("../../config.json");

module.exports = {
    name: "entrar",
    description: "Faz o bot entrar na sua call",
    type: ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        if (interaction.user.id !== owner) {
            return interaction.reply({ content: `❌ | Você não pode usar este comando!`, ephemeral: true });
        }

        const membro = interaction.member;
        const canalVoz = membro?.voice?.channel;

        if (!canalVoz) {
            return interaction.reply({
                content: `❌ | Você precisa estar em uma call para usar este comando!`,
                ephemeral: true
            });
        }

        const conexaoExistente = getVoiceConnection(interaction.guildId);
        if (conexaoExistente) {
            conexaoExistente.destroy();
        }

        joinVoiceChannel({
            channelId: canalVoz.id,
            guildId: interaction.guildId,
            adapterCreator: interaction.guild.voiceAdapterCreator,
            selfDeaf: true,
            selfMute: true,
        });

        const embed = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle('🎙️ Entrei na Call')
            .setDescription(`Estou em **${canalVoz.name}** agora!`)
            .setFooter({ text: 'XDVZ Bot • Use /sair para me remover' });

        await interaction.reply({ embeds: [embed] });
    }
}
