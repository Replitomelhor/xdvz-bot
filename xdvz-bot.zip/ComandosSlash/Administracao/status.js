const { EmbedBuilder, ApplicationCommandType } = require("discord.js");
const { owner } = require("../../config.json");

const startTime = Date.now();

function formatarUptime(ms) {
    const totalSegundos = Math.floor(ms / 1000);
    const dias = Math.floor(totalSegundos / 86400);
    const horas = Math.floor((totalSegundos % 86400) / 3600);
    const minutos = Math.floor((totalSegundos % 3600) / 60);
    const segundos = totalSegundos % 60;

    const partes = [];
    if (dias > 0) partes.push(`${dias}d`);
    if (horas > 0) partes.push(`${horas}h`);
    if (minutos > 0) partes.push(`${minutos}m`);
    partes.push(`${segundos}s`);

    return partes.join(' ');
}

module.exports = {
    name: "status",
    description: "Veja informações e status do bot",
    type: ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        if (interaction.user.id !== owner) {
            return interaction.reply({ content: `❌ | Você não pode usar este comando!`, ephemeral: true });
        }

        await interaction.deferReply({ ephemeral: true });

        const uptime = formatarUptime(Date.now() - startTime);
        const memoriaUsada = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2);
        const memoriaTotal = (process.memoryUsage().heapTotal / 1024 / 1024).toFixed(2);
        const totalMembros = client.guilds.cache.reduce((a, b) => a + b.memberCount, 0);
        const agora = new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });
        const ping = Math.round(client.ws.ping);

        const embed = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle('📊 Status do Bot')
            .setThumbnail(client.user.displayAvatarURL())
            .addFields(
                { name: '🤖 Bot', value: client.user.tag, inline: true },
                { name: '📡 Ping', value: `${ping}ms`, inline: true },
                { name: '⏱️ Online há', value: uptime, inline: true },
                { name: '🌐 Servidores', value: `${client.guilds.cache.size}`, inline: true },
                { name: '📢 Canais', value: `${client.channels.cache.size}`, inline: true },
                { name: '👥 Membros', value: `${totalMembros}`, inline: true },
                { name: '💾 Memória', value: `${memoriaUsada} MB / ${memoriaTotal} MB`, inline: true },
                { name: '🕐 Horário', value: agora, inline: true },
            )
            .setFooter({ text: 'XDVZ Bot • Hospedado no Render.com' });

        await interaction.editReply({ embeds: [embed] });
    }
}
