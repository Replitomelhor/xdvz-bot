const { EmbedBuilder, ApplicationCommandType } = require("discord.js");
const { owner } = require("../../config.json");
const fs = require("fs");
const path = require("path");

const arquivoReinicializacoes = path.join(__dirname, "../../DataBaseJson/reinicializacoes.json");

module.exports = {
    name: "reiniciar",
    description: "Reinicia o bot remotamente",
    type: ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        if (interaction.user.id !== owner) {
            return interaction.reply({ content: `❌ | Você não pode usar este comando!`, ephemeral: true });
        }

        const agora = new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });

        try {
            let lista = [];
            if (fs.existsSync(arquivoReinicializacoes)) {
                lista = JSON.parse(fs.readFileSync(arquivoReinicializacoes, 'utf8'));
            }
            lista.push(`${agora} (manual via /reiniciar)`);
            if (lista.length > 50) lista = lista.slice(-50);
            fs.writeFileSync(arquivoReinicializacoes, JSON.stringify(lista, null, 2));
        } catch (_) {}

        const embed = new EmbedBuilder()
            .setColor(0xff9800)
            .setTitle('🔄 Reiniciando...')
            .setDescription(`O bot vai reiniciar agora e voltar em alguns segundos.\n\n🕐 **Horário:** ${agora}`)
            .setFooter({ text: 'XDVZ Bot • Render.com vai reiniciar automaticamente' });

        await interaction.reply({ embeds: [embed] });

        setTimeout(() => {
            process.exit(0);
        }, 2000);
    }
}
