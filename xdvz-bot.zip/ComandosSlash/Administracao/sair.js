const { ApplicationCommandType, EmbedBuilder } = require("discord.js");
const { getVoiceConnection } = require("@discordjs/voice");
const { owner } = require("../../config.json");

module.exports = {
    name: "sair",
    description: "Faz o bot sair da call",
    type: ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        if (interaction.user.id !== owner) {
            return interaction.reply({ content: `❌ | Você não pode usar este comando!`, ephemeral: true });
        }

        const conexao = getVoiceConnection(interaction.guildId);

        if (!conexao) {
            return interaction.reply({
                content: `❌ | Não estou em nenhuma call no momento!`,
                ephemeral: true
            });
        }

        conexao.destroy();

        const embed = new EmbedBuilder()
            .setColor(0xff5252)
            .setTitle('👋 Saí da Call')
            .setDescription('Fui removido da call com sucesso.')
            .setFooter({ text: 'XDVZ Bot' });

        await interaction.reply({ embeds: [embed] });
    }
}
