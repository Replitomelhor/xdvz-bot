const { EmbedBuilder, ApplicationCommandType } = require("discord.js");
const { owner } = require("../../config.json");
const fs = require("fs");
const path = require("path");

const arquivoReinicializacoes = path.join(__dirname, "../../DataBaseJson/reinicializacoes.json");

function formatarUptime(ms) {
    const totalSegundos = Math.floor(ms / 1000);
    const dias = Math.floor(totalSegundos / 86400);
    const horas = Math.floor((totalSegundos % 86400) / 3600);
    const minutos = Math.floor((totalSegundos % 3600) / 60);
    const segundos = totalSegundos % 60;

    const partes = [];
    if (dias > 0) partes.push(`${dias}d`);
    if (horas > 0) partes.push(`${horas}h`);
    if (minutos > 0) partes.push(`${minutos}m`);
    partes.push(`${segundos}s`);
    return partes.join(' ');
}

module.exports = {
    name: "uptime",
    description: "Veja o tempo online do bot e histórico de reinícios",
    type: ApplicationCommandType.ChatInput,

    run: async (client, interaction) => {
        if (interaction.user.id !== owner) {
            return interaction.reply({ content: `❌ | Você não pode usar este comando!`, ephemeral: true });
        }

        await interaction.deferReply({ ephemeral: true });

        const uptimeAtual = formatarUptime(client.uptime);
        const agora = new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });

        let historico = [];
        try {
            const dados = fs.readFileSync(arquivoReinicializacoes, "utf8");
            historico = JSON.parse(dados);
        } catch (_) {}

        const ultimos = historico.slice(-5).reverse();
        const historicoTexto = ultimos.length > 0
            ? ultimos.map((r, i) => `**${i + 1}.** ${r}`).join("\n")
            : "Nenhum reinício registrado ainda.";

        const embed = new EmbedBuilder()
            .setColor(0x00bcd4)
            .setTitle('⏱️ Uptime do Bot')
            .addFields(
                { name: '🟢 Online há', value: uptimeAtual, inline: true },
                { name: '🔁 Total de reinícios', value: `${historico.length}`, inline: true },
                { name: '🕐 Horário atual', value: agora, inline: false },
                { name: '📋 Últimos 5 reinícios', value: historicoTexto, inline: false },
            )
            .setFooter({ text: 'XDVZ Bot • Render.com' });

        await interaction.editReply({ embeds: [embed] });
    }
}
