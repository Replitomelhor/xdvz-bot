const OWNER_ID = '477655681042874369';

async function notificarDono(client, mensagem) {
    try {
        const dono = await client.users.fetch(OWNER_ID);
        await dono.send(mensagem);
    } catch (err) {
        console.log('Não foi possível enviar notificação ao dono:', err.message);
    }
}

module.exports = { notificarDono };
