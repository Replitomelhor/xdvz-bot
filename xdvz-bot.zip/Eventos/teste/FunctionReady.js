
const { carregarCache } = require('../../Handler/EmojiFunctions');
const { ActivityType, EmbedBuilder } = require('discord.js');
const { CloseThreds } = require('../../Functions/CloseThread');
const { VerificarPagamento } = require('../../Functions/VerficarPagamento');
const { EntregarPagamentos } = require('../../Functions/AprovarPagamento');
const { CheckPosition } = require('../../Functions/PosicoesFunction.js');
const { configuracao } = require('../../DataBaseJson');
const { Varredura } = require('../../Functions/Varredura.js');
const { notificarDono } = require('../../Functions/Notificacoes.js');
const fs = require('fs');
const path = require('path');

const arquivoReinicializacoes = path.join(__dirname, '../../DataBaseJson/reinicializacoes.json');

function registrarInicializacao() {
    try {
        let lista = [];
        if (fs.existsSync(arquivoReinicializacoes)) {
            lista = JSON.parse(fs.readFileSync(arquivoReinicializacoes, 'utf8'));
        }
        const agora = new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });
        lista.push(agora);
        if (lista.length > 50) lista = lista.slice(-50);
        fs.writeFileSync(arquivoReinicializacoes, JSON.stringify(lista, null, 2));
    } catch (_) {}
}

const STATUSES = ['XDVZ Applications', 'XDVZ Sallers'];

module.exports = {
    name: 'ready',

    run: async (client) => {
        let indiceAtual = 0;

        function setStreamingStatus() {
            client.user.setPresence({
                activities: [
                    {
                        name: STATUSES[indiceAtual],
                        type: ActivityType.Streaming,
                        url: 'https://www.twitch.tv/placeholder',
                    },
                ],
                status: 'online',
            });
            indiceAtual = (indiceAtual + 1) % STATUSES.length;
        }

        setStreamingStatus();
        setInterval(setStreamingStatus, 15000);

        if (client.guilds.cache.size > 1) {
            client.guilds.cache.forEach(guild => {
                guild.leave()
                    .then(() => console.log(`Bot saiu do servidor: ${guild.name}`))
                    .catch(error => console.error(`Erro ao sair do servidor: ${guild.name}`, error));
            });
        }

        const verifyPayments = () => { VerificarPagamento(client); };
        const deliverPayments = () => { EntregarPagamentos(client); };
        const closeThreads = () => { CloseThreds(client); };

        Varredura(client);

        setInterval(verifyPayments, 10000);
        setInterval(deliverPayments, 14000);
        setInterval(closeThreads, 60000);

        registrarInicializacao();

        const agora = new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });

        const embed = new EmbedBuilder()
            .setColor(0x00e676)
            .setTitle('✅ Bot Online')
            .setDescription(`**${client.user.tag}** foi iniciado com sucesso!`)
            .addFields(
                { name: '🌐 Servidores', value: `${client.guilds.cache.size}`, inline: true },
                { name: '👥 Membros', value: `${client.guilds.cache.reduce((a, b) => a + b.memberCount, 0)}`, inline: true },
                { name: '🕐 Horário', value: agora, inline: false },
            )
            .setFooter({ text: 'XDVZ Bot • Hospedado no Render.com' });

        await notificarDono(client, { embeds: [embed] });

        console.log(`${client.user.tag} Foi iniciado \n - Atualmente ${client.guilds.cache.size} servidores!\n - Tendo acesso a ${client.channels.cache.size} canais!\n - Contendo ${client.guilds.cache.reduce((a, b) => a + b.memberCount, 0)} usuarios!`);

        CheckPosition(client);
        carregarCache();
    }
}
