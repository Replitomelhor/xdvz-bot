const { GatewayIntentBits, Client, Collection, EmbedBuilder } = require("discord.js")
const { AtivarIntents } = require("./Functions/StartIntents");
const { notificarDono } = require("./Functions/Notificacoes");
const http = require("http");

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildVoiceStates,
        GatewayIntentBits.DirectMessages,
    ]
});

const estatisticasStormInstance = require("./Functions/VariaveisEstatisticas");
const EstatisticasStorm = new estatisticasStormInstance();
module.exports = { EstatisticasStorm }

AtivarIntents()

const events = require('./Handler/events')
const slash = require('./Handler/slash');

slash.run(client)
events.run(client)

client.slashCommands = new Collection();

client.on('guildCreate', guild => {
    if (client.guilds.cache.size > 1) {
        guild.leave()
    }
})

async function enviarErro(mensagem, erro) {
    console.log(`🚫 Erro Detectado:\n\n` + erro);
    if (!client.isReady()) return;

    try {
        const agora = new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' });
        const embed = new EmbedBuilder()
            .setColor(0xff1744)
            .setTitle('🚫 Erro Detectado no Bot')
            .setDescription(`\`\`\`${String(erro).slice(0, 1000)}\`\`\``)
            .addFields({ name: '🕐 Horário', value: agora })
            .setFooter({ text: 'XDVZ Bot • Verifique os logs no Render.com' });

        await notificarDono(client, { embeds: [embed] });
    } catch (_) {}
}

process.on('unhandledRejection', (reason) => {
    enviarErro('unhandledRejection', reason);
});
process.on('uncaughtException', (error) => {
    enviarErro('uncaughtException', error);
});
process.on('uncaughtExceptionMonitor', (error) => {
    enviarErro('uncaughtExceptionMonitor', error);
});

const PORT = process.env.PORT || 3000;
http.createServer((req, res) => {
    res.writeHead(200);
    res.end('XDVZ Bot online!');
}).listen(PORT, () => {
    console.log(`Keep-alive server rodando na porta ${PORT}`);
});

client.login(process.env.DISCORD_TOKEN);
